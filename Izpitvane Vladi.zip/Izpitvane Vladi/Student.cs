﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Izpitvane_Vladi
{
    class Student:Human

    {
        private string facyltet;

        public Student()
        {

        }

        public Student(string facultet) : base()
        {
            Facultet = facultet;
        }

        public string Facultet
        {
            get { return facyltet; }
            set 
            {
                if (value.Length<5&&value.Length>10)
                {
                    throw new ArgumentException("Invalid faculty number!");
                }
                facyltet = value; 
            }
        }

        public void Dislpay()
        {
            Console.WriteLine($"Name:{Name}\nLastName:{LastName}\nFacultetenNomer{Facultet}"); 
        }

    }
}
