﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Izpitvane_Vladi
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string stName = Console.ReadLine();
                string stLastName = Console.ReadLine();
                string facult = Console.ReadLine();
                string workName = Console.ReadLine();
                string workLastName = Console.ReadLine();
                double weekly = double.Parse(Console.ReadLine());
                double hours = double.Parse(Console.ReadLine());
                Student st = new Student();
                Console.WriteLine(stName,stLastName,facult);
                Worker wk = new Worker();
                Console.WriteLine(workName,workLastName,weekly,hours,wk.Salary());

            }
            catch (ArgumentException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
