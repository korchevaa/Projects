﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Izpitvane_Vladi
{
    class Human
    {
        private string name;

        public string Name
        {
            get { return name; }
            set 
            {
                if (!char.IsUpper(value[0]))
                {
                    throw new ArgumentException("Expected upper case letter! Argument: firstName");
                }
                if (value.Length<3)
                {
                    throw new ArgumentException("Expected length at least 4 symbols! Argument: firstName");
                }
                name = value; 
            }
        }
        private string lastName;

        public Human()
        {
        }

        public Human(string name, string lastName)
        {
            Name = name;
            LastName = lastName;
        }

        public string LastName
        {
            get { return lastName; }
            set 
            {
                if (char.IsUpper(value[0]))
                {
                    throw new ArgumentException("Expected upper case letter! Argument: lastName");
                }
                if (value.Length < 2)
                {
                    throw new ArgumentException("Expected length at least 3 symbols! Argument: lastName ");
                }
                lastName = value; 
            }
        }
        //public virtual void Dispaly()
        //{
        //    Console.WriteLine($"Name:{Name}\nLastname{LastName}");
        //}

        public override string ToString()
        {
            return $"Name:{Name}\nLastname{LastName}";
        }
    }
}
