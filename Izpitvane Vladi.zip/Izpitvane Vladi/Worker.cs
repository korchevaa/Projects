﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Izpitvane_Vladi
{
    class Worker:Human
    {
        private double weekly;

        public double Weekly
        {
            get { return weekly; }
            set
            {
                if (value<10)
                {
                    throw new ArgumentException("Expected value mismatch! Argument: weekSalary");
                }
                weekly = value; 
            }
        }
        private double workTime;

        public Worker(double weekly, double workTime):base()
        {
            Weekly = weekly;
            WorkTime = workTime;
        }

        public Worker()
        {
        }

        public double WorkTime
        {
            get { return workTime; }
            set
            {
                if (value<1&&value>12)
                {
                    throw new ArgumentException("Expected value mismatch! Argument: workHoursPerDay");
                }
                workTime = value;
            }
        }
        public double Salary()
        {
            return weekly / (workTime * 5);
        }
        //public override void Dispaly()
        //{
        //    Console.WriteLine($"Name:{Name}\nLastName:{LastName}\nWeek Salary:{Weekly}\nHours per day:{WorkTime}\nSalary per hour:{Salary}");
        //}

        public override string ToString()
        {
            return $"Name:{Name}\nLastName:{LastName}\nWeek Salary:{Weekly}\nHours per day:{WorkTime}";
        }
    }
}
